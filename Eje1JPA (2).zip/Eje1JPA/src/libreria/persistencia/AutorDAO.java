
package libreria.persistencia;

import libreria.Entidad.Autor;
import libreria.Entidad.Editorial;

public class AutorDAO extends DAO<Autor>{
    public void crearAutor(){
        super.guardar();
    }
    
    public void buscar(int IdSQL){
        Editorial editorial = em.find(Editorial.class, IdSQL);
        
        
        
    }
    
}
